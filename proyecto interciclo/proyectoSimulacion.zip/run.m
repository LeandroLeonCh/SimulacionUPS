type = 'recovered'; % 'confirmed','deaths','recovered'

[dataMatrix] = readCoronaData(type);

[dataTable,timeVector,mergedData] = processCoronaData(dataMatrix);


plotCoronaData(timeVector,mergedData,{'Ecuador'},type);
casos = plotCoronaData(timeVector,mergedData,{'Ecuador'},type);
modeloMatematico(timeVector,casos)

