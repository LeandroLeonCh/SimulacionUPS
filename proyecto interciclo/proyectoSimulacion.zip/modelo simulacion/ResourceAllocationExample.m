%% Resource Allocation from Multiple Pools

%Copyright 2005-2016 The MathWorks, Inc.

%% Overview
% This example shows a technique for allocating resources from multiple
% resource pools. It shows how to choose a pool from which to draw a
% resource, based on given criteria.

%% Structure of the Model
% There are two main components of the model.
%
% *  Request Generation and Queuing
% *  Resource Pools and Resource Allocation

model = 'proyecto';
open_system(model);
scopes = find_system(model, 'LookUnderMasks', 'on', 'BlockType', 'Scope');
cellfun(@(x)close_system(x),scopes);
sim(model);

%% Request Generation and Queuing
% The Entity Generator block generates requests using a Uniform
% distribution. In order for these requests to be acted upon, they require
% a resource from one of the two resource pools. Each of the requests has
% an attribute that specifies the kind of resource it requires. The
% requests move to one of the queues dedicated for each type of resource
% pool.

%% Resource Pools and Resource Allocation
% The model has two resource pools, Type 1 and Type 2. 
% The Type 1 and Type 2 Resource Pool blocks model the
% pools. These pools hold the resources before and after their use. The
% size of each pool is defined as parameter of the corresponding block.

open_system([model '/Type 1 Resource Pool'],'force');

%%
% The Resource Acquirer and Resource Releaser blocks manage the acquisition
% and the return of the resource. The Entity Server block in that region
% models the duration for which the resources are used.
% 
%% Results and Displays
% This model includes the following plots.
%%
% *  The Pending Type 1 Requests and Pending Type 2 Requests plots show the
% number of requests waiting for resources from the corresponding pools.
% You can see that more requests for Type 1 resources wait compared to
% requests for Type
% 2 resources.

open_system([model '/Scopes and Displays/Type 1 Pending Requests']);
open_system([model '/Scopes and Displays/Type 2 Pending Requests']);

%%
% *  The Type 1 Resources in Use and the Type 2 Resources in Use plots show
% the instantaneous values of the number of resources available for use in
% the corresponding resource pools.

open_system([model '/Scopes and Displays/Type 1 Resources in Use']);
open_system([model '/Scopes and Displays/Type 2 Resources in Use']);

%% 
% *  The average wait time for acquiring each type of resources is
% reported by the Resource Acquire blocks for Type 1 Resource and Type 2
% Resource.

fprintf('Average Wait Time for Resource Type 1 = %.2f\n', AvgWaitTimeReqsType1.signals.values(end));
fprintf('Average Wait Time for Resource Type 2 = %.2f\n', AvgWaitTimeReqsType2.signals.values(end));

%%
% *  The average amount of resources in use at each resource pool is
% reported by Resource Pool blocks for Type 1 Resource and Type 2 Resource.

fprintf('Average Use of Resource Type 1 = %.2f\n', AvgResourcesInUseType1.signals.values(end));
fprintf('Average Use of Resource Type 2 = %.2f\n', AvgResourcesInUseType2.signals.values(end));

%%
% The model has the following configuration:
%
% *  Resource request distribution: Type 1 = 0.4, Type 2 = 0.6
% *  Duration of Type 1 resource use      : 0.05
% *  Duration of Type 2 resource use      : 0.07
% *  Type 1 pool size                     : 4
% *  Type 2 pool size                     : 8

%%
% From the above results, you can see that the larger pool size of Type 2
% resources results in a lower average wait time even with a higher request
% rate and longer duration of resource use.

%% Experimenting with the Model
% To vary system behaviors, like the number of resources available and wait
% times for resources, change the following settings:
%
% *  The probabilities for changing the generation rate of the resource
% requests in the |Intergeneration time action| parameter of Entity
% Generator.
% *  The |Service time| parameter of the Entity
%    Server blocks in the Resource Pool and Resource Allocation regions of
%    the model for changing the duration of the resource usage.
% *  The |Resource amount| parameter of the Type 1 Resource Pool and Type 2
%    Resource Pool blocks to change the number of resources in the pool.

%% 
%cleanup
%bdclose(model);
%clear model scopes
