ds = datastore('covid_19_clean_complete.csv');
ds.SelectedVariableNames = {'Country/Region', 'Confirmed'};
ds.TreatAsMissing = 'NA';
tt  = tall(ds) % Tall table